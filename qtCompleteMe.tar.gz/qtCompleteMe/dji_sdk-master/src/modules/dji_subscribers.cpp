#include <dji_sdk/dji_subscribers.h>

namespace subscribers
{

};
