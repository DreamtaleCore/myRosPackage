#ifndef __DJI_SDK_COMMANDS_H__
#define __DJI_SDK_COMMANDS_H__
namespace dji_commands
{
    void set_takeoff();
    void set_land();
    void set_loiter();
    void set_return2home();
}
#endif
