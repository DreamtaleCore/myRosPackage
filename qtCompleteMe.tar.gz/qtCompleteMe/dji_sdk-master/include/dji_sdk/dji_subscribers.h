//
// Created by Hao Xu on 15/5/5.
//

#ifndef DJI_SDK_DJI_SUBSCRIBERS_H
#define DJI_SDK_DJI_SUBSCRIBERS_H

#include <ros/ros.h>
/*
namespace subscribers
{

    extern ros::Subscriber cmd_data_sub, nav_open_close_sub,
            ctrl_mode_sub, ctrl_data_sub, simple_task_sub,
            activation_sub;

    extern ros::Subscriber vel_sp_sub, acc_sp_sub,
            gimbal_sp_sub, pos_sp_sub,
            pos_sp, look_at_sp_sub;

    int init_subscibers(ros::NodeHandle & nh);
};
*/
#endif //DJI_SDK_DJI_SUBSCRIBERS_H
